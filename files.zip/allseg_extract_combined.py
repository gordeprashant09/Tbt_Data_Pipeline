#!/usr/bin/env python3
"""
allseg_extract_combined.py
==========================
Combined FO + CM extraction pipeline.

What this does:
  - Runs FO pipeline  (FUTSTK, FUTIDX, OPTSTK, OPTIDX parquet)
  - Runs CM pipeline  (equities parquet + CM RDS)
  - Converts FUTSTK parquets → RDS (always, hardcoded)
  - TAR + pushes everything to NAS

Output:
  Local shared:
    /home/alpha/shared/DATE/
      ├── FUTSTK/SYMBOL/DATE_FUTSTK_SYMBOL_EXPIRY.parquet
      ├── FUTIDX/SYMBOL/DATE_FUTIDX_SYMBOL_EXPIRY.parquet
      ├── CM_Data/DATE_SYMBOL_EQ.parquet
      ├── support_docs/
      ├── sanity_check_DATE.csv
      ├── allseg_row_counts_DATE.csv
      ├── TBT_SYMBOL_DATE.rds          ← FUTSTK RDS (top level)
      ├── TBT_SYMBOL_DATE_aux.rds
      ├── TBT_SYMBOL_DATE.rds          ← CM RDS (top level, same naming)
      └── TBT_SYMBOL_DATE_aux.rds

  NAS:
    /mnt/historical_data/tbt_data/parsed_data/DATE/
      ├── DATE_parsed.tar          ← all FO parquets bundled
      └── DATE_cm_parsed.tar       ← all CM parquets bundled

Logs:
  /home/alpha/fo_DATE.log
  /home/alpha/cm_DATE.log

Status:
  /home/alpha/allseg_DATE_work/status.json

Usage:
  # single date
  python allseg_extract_combined.py --date 20260320

  # multiple dates — sequential
  python allseg_extract_combined.py --date 20260320 20260304 20260305

  # single segment only
  python allseg_extract_combined.py --date 20260320 --segment FO
  python allseg_extract_combined.py --date 20260320 --segment CM

  # force clean restart
  python allseg_extract_combined.py --date 20260320 --clean

  # resume crashed run — just re-run same command
  python allseg_extract_combined.py --date 20260320
"""

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

# ── import RDS manager ─────────────────────────────────────────────────────
_this_dir = Path(__file__).parent
sys.path.insert(0, str(_this_dir))
try:
    from allseg_rds_converter import RdsJobManager
    HAS_RDS = True
except ImportError as _e:
    HAS_RDS = False
    print(f"[WARN] allseg_rds_converter not found — FO RDS disabled: {_e}")

# ══════════════════════════════════════════════════════════════════
# CONFIG
# ══════════════════════════════════════════════════════════════════

PYTHON      = sys.executable
SCRIPT_DIR  = Path("/media/svipl/Data/historical_data")
FO_SCRIPT   = SCRIPT_DIR / "allseg_extract_full_tar_alpha_final.py"
CM_SCRIPT   = SCRIPT_DIR / "allseg_extract_cm_final.py"

# Logs written directly to /home/alpha/
LOG_DIR     = Path("/home/alpha")
WORK_BASE   = Path("/home/alpha")

# Local shared output root
LOCAL_SHARED_ROOT = Path("/home/alpha/shared")

# NAS output
NAS_PARSED_ROOT = Path("/mnt/historical_data/tbt_data/parsed_data")


# ══════════════════════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════════════════════

def log(msg: str):
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def read_status(status_file: Path) -> dict:
    if status_file.exists():
        try:
            with open(status_file) as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def write_status(status_file: Path, status: dict):
    status_file.parent.mkdir(parents=True, exist_ok=True)
    with open(status_file, "w") as f:
        json.dump(status, f, indent=2)
    log(f"[STATUS] {status_file}  {json.dumps(status)}")


# ══════════════════════════════════════════════════════════════════
# SINGLE DATE PIPELINE
# ══════════════════════════════════════════════════════════════════

def run_one_date(date: str, segments_to_run: list,
                 clean: bool, status: dict) -> dict:
    """
    Run full pipeline for one date.
    Returns updated status dict.
    """
    work_dir    = WORK_BASE / f"allseg_{date}_work"
    status_file = work_dir / "status.json"

    # Shared date dir — where local output lands
    shared_date_dir = LOCAL_SHARED_ROOT / date
    shared_date_dir.mkdir(parents=True, exist_ok=True)

    log("=" * 65)
    log(f"  DATE        : {date}")
    log(f"  Segments    : {segments_to_run}")
    log(f"  Clean       : {clean}")
    log(f"  Shared dir  : {shared_date_dir}")
    log(f"  NAS dir     : {NAS_PARSED_ROOT / date}")
    log("=" * 65)

    # ── Clean restart ─────────────────────────────────────────────
    if clean and work_dir.exists():
        import shutil
        log(f"[CLEAN] Removing work dir: {work_dir}")
        shutil.rmtree(work_dir)
        status = {}

    work_dir.mkdir(parents=True, exist_ok=True)

    # ── STAGE 1: FO + CM in parallel ─────────────────────────────
    processes = {}
    log_files = {}
    results   = {}

    for seg in segments_to_run:
        if status.get(seg) == "done" and not clean:
            log(f"[SKIP] {seg} already done — skipping")
            results[seg] = "done"
            continue

        script = FO_SCRIPT if seg == "FO" else CM_SCRIPT
        if not script.exists():
            log(f"[ERROR] Script not found: {script}")
            results[seg] = "failed"
            continue

        # Logs go directly to /home/alpha/fo_DATE.log and cm_DATE.log
        log_path = LOG_DIR / f"{seg.lower()}_{date}.log"
        cmd      = [PYTHON, "-u", str(script), "--date", date]
        if clean and seg == "FO":
            cmd.append("--clean")

        log(f"[LAUNCH] {seg} → log: {log_path}")
        lf   = open(log_path, "w")
        proc = subprocess.Popen(cmd, stdout=lf, stderr=subprocess.STDOUT)
        processes[seg] = proc
        log_files[seg] = lf
        log(f"[LAUNCH] {seg} PID={proc.pid}")

    # ── Wait for FO + CM ──────────────────────────────────────────
    t_start   = time.time()
    remaining = dict(processes)

    while remaining:
        for seg, proc in list(remaining.items()):
            ret = proc.poll()
            if ret is not None:
                elapsed = round(time.time() - t_start)
                if ret == 0:
                    results[seg] = "done"
                    log(f"[DONE] {seg} finished in {elapsed}s ✅")
                else:
                    results[seg] = "failed"
                    log(f"[FAIL] {seg} failed (exit={ret}) after {elapsed}s ❌")
                    log(f"[FAIL] Log: {LOG_DIR / f'{seg.lower()}_{date}.log'}")
                del remaining[seg]
        if remaining:
            time.sleep(10)

    for lf in log_files.values():
        lf.close()

    status.update(results)
    write_status(status_file, status)

    # ── STAGE 2: FO RDS — FUTSTK only ─────────────────────────────
    # CM RDS is handled inside allseg_extract_cm_final.py itself.
    # FO RDS runs here after FO pipeline finishes (parquets are in shared).
    fo_done     = results.get("FO") == "done" or status.get("FO") == "done"
    rds_already = status.get("RDS") == "done" and not clean

    if rds_already:
        log(f"[SKIP] FO RDS already done for {date}")
        rds_result = {"status": "done", "failed_symbols": []}

    elif fo_done and HAS_RDS:
        log(f"[RDS-FO] Starting FUTSTK RDS conversion for {date} ...")
        t0 = time.time()

        try:
            rds_result = _run_fo_rds_stage(date, shared_date_dir, work_dir)
        except Exception as e:
            log(f"[RDS-FO] ERROR: {e}")
            rds_result = {"status": "failed", "failed_symbols": []}

        elapsed = round(time.time() - t0)
        log(f"[RDS-FO] Done in {elapsed}s — status={rds_result['status']}")

    else:
        reason = "FO failed" if not fo_done else "RDS module not available"
        log(f"[RDS-FO] Skipping ({reason})")
        rds_result = {"status": "skipped", "failed_symbols": []}

    status["RDS"]               = rds_result["status"]
    status["RDS_failed_symbols"] = rds_result["failed_symbols"]
    write_status(status_file, status)

    # ── STAGE 3: Summary ──────────────────────────────────────────
    total_elapsed = round(time.time() - t_start)
    log("=" * 65)
    log(f"  DATE {date} COMPLETE  ({total_elapsed}s)")
    for seg in ["FO", "CM", "RDS"]:
        s    = status.get(seg, "skipped")
        icon = "✅" if s == "done" else ("⚠️" if s == "partial" else ("❌" if s == "failed" else "—"))
        log(f"  {seg:6s} : {s}  {icon}")
    if status.get("RDS_failed_symbols"):
        log(f"  RDS failed symbols:")
        for sym in status["RDS_failed_symbols"]:
            log(f"    ✗ {sym}")
    log(f"\n  Output:")
    log(f"    Shared : {shared_date_dir}")
    log(f"    NAS    : {NAS_PARSED_ROOT / date}")
    log("=" * 65)

    return status


# ══════════════════════════════════════════════════════════════════
# FO RDS STAGE — scans shared FUTSTK dir, submits all to RdsJobManager
# ══════════════════════════════════════════════════════════════════

def _run_fo_rds_stage(date: str, shared_date_dir: Path, work_dir: Path) -> dict:
    """
    Scan shared_date_dir/FUTSTK/ for parquets and convert to RDS.
    RDS output goes to shared_date_dir/ (top level, not inside FUTSTK/).
    """
    futstk_dir = shared_date_dir / "FUTSTK"

    if not futstk_dir.exists():
        log(f"[RDS-FO] FUTSTK dir not found: {futstk_dir} — trying NAS ...")
        futstk_dir = NAS_PARSED_ROOT / date / "FUTSTK"
        if not futstk_dir.exists():
            log(f"[RDS-FO] FUTSTK dir not found on NAS either — skipping RDS")
            return {"status": "skipped", "failed_symbols": []}

    mgr = RdsJobManager(
        date            = date,
        shared_date_dir = shared_date_dir,
        overwrite       = False,
    )

    # Pattern: DATE_FUTSTK_SYMBOL_EXPIRY.parquet
    pattern = f"{date}_FUTSTK_*.parquet"
    found   = 0

    for sym_dir in sorted(futstk_dir.iterdir()):
        if not sym_dir.is_dir():
            continue
        for pq in sorted(sym_dir.glob(pattern)):
            # Parse: DATE_FUTSTK_SYMBOL_EXPIRY.parquet
            stem  = pq.stem  # e.g. 20260320_FUTSTK_RELIANCE_1464273000
            parts = stem.split("_")
            if len(parts) < 4:
                continue
            # parts[0]=date, parts[1]=FUTSTK, parts[2:-1]=symbol, parts[-1]=expiry
            expiry = parts[-1]
            symbol = "_".join(parts[2:-1])
            mgr.submit(pq, symbol, expiry)
            found += 1

    log(f"[RDS-FO] Submitted {found} FUTSTK parquets")

    results      = mgr.wait_and_retry()
    summary_path = work_dir / f"rds_fo_summary_{date}.csv"
    mgr.write_summary(summary_path, results)

    failed_syms = [
        f"FUTSTK/{r['symbol']}/{r['expiry']}"
        for r in results.get("retried_fail", [])
    ]
    rds_status = "done" if not failed_syms else "partial"

    return {"status": rds_status, "failed_symbols": failed_syms}


# ══════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="Combined FO+CM+RDS extraction pipeline"
    )
    parser.add_argument(
        "--date", required=True, nargs="+",
        help="One or more dates YYYYMMDD. Processed sequentially.",
        metavar="YYYYMMDD",
    )
    parser.add_argument(
        "--segment", choices=["FO", "CM"], default=None,
        help="Run only FO or CM (default: both)",
    )
    parser.add_argument(
        "--clean", action="store_true",
        help="Force clean restart — delete existing work dir and status",
    )
    args = parser.parse_args()

    dates = args.date

    # Determine which segments to run
    if args.segment:
        base_segments = [args.segment]
    else:
        base_segments = ["FO", "CM"]

    log("=" * 65)
    log("  COMBINED PIPELINE")
    log(f"  Dates        : {dates}")
    log(f"  Segments     : {base_segments}")
    log(f"  RDS (FO)     : FUTSTK only (hardcoded)")
    log(f"  RDS (CM)     : EQ series (runs inside CM pipeline)")
    log(f"  Clean        : {args.clean}")
    log(f"  FO script    : {FO_SCRIPT}")
    log(f"  CM script    : {CM_SCRIPT}")
    log(f"  Local shared : {LOCAL_SHARED_ROOT}")
    log(f"  NAS          : {NAS_PARSED_ROOT}")
    log(f"  Logs         : {LOG_DIR}/fo_DATE.log  {LOG_DIR}/cm_DATE.log")
    log("=" * 65)

    # ── Multi-date loop — sequential ─────────────────────────────
    all_statuses = {}
    any_failed   = False

    for i, date in enumerate(dates, 1):
        log(f"\n{'='*65}")
        log(f"  [{i}/{len(dates)}] Processing date: {date}")
        log(f"{'='*65}")

        work_dir    = WORK_BASE / f"allseg_{date}_work"
        status_file = work_dir  / "status.json"

        # Load existing status unless --clean
        status = {} if args.clean else read_status(status_file)

        # Determine which segments still need to run
        segments_to_run = []
        for seg in base_segments:
            if status.get(seg) == "done" and not args.clean:
                log(f"[SKIP] {seg} already done for {date} — use --clean to rerun")
            else:
                segments_to_run.append(seg)

        # Check if everything already done
        rds_skip = (
            status.get("RDS") == "done"
            and not args.clean
            and not segments_to_run
        )

        if not segments_to_run and rds_skip:
            log(f"[SKIP] {date} fully done — skipping")
            all_statuses[date] = status
            continue

        # Run this date
        final_status = run_one_date(
            date            = date,
            segments_to_run = segments_to_run,
            clean           = args.clean,
            status          = status,
        )

        all_statuses[date] = final_status

        for seg in base_segments:
            if final_status.get(seg) == "failed":
                any_failed = True
        if final_status.get("RDS") == "partial":
            log(f"[WARN] {date} FO RDS partial — some symbols failed")

    # ── Final summary across all dates ───────────────────────────
    log("\n" + "=" * 65)
    log("  ALL DATES SUMMARY")
    log("=" * 65)

    for date, status in all_statuses.items():
        fo_s  = status.get("FO",  "skipped")
        cm_s  = status.get("CM",  "skipped")
        rds_s = status.get("RDS", "skipped")
        log(f"  {date}  FO={fo_s:7s}  CM={cm_s:7s}  RDS(FO)={rds_s}")

    log("=" * 65)

    if any_failed:
        failed_dates = [
            d for d, s in all_statuses.items()
            if s.get("FO") == "failed" or s.get("CM") == "failed"
        ]
        log(f"[FAILED] Some dates failed: {failed_dates}")
        log(f"[RETRY]  Re-run: python allseg_extract_combined.py "
            f"--date {' '.join(failed_dates)}")
        sys.exit(1)
    else:
        log("[SUCCESS] All dates completed ✅")


if __name__ == "__main__":
    main()
