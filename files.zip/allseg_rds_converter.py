#!/usr/bin/env python3
"""
allseg_rds_converter.py
=======================
Python wrapper for RDS conversion.

FO  : FUTSTK only (hardcoded — no mode flag needed)
CM  : EQ series equities via extract_cash_parquet_to_rds.R

RDS output goes to:
  /home/alpha/shared/DATE/TBT_SYMBOL_DATE.rds
  /home/alpha/shared/DATE/TBT_SYMBOL_DATE_aux.rds

Both FO (FUTSTK) and CM RDS land at the DATE top-level folder,
NOT inside FUTSTK/ or CM_Data/ subfolders.
"""

import csv
import os
import subprocess
import sys
import threading
import time
from concurrent.futures import Future, ThreadPoolExecutor, as_completed
from pathlib import Path

# ══════════════════════════════════════════════════════════════════
# CONFIG
# ══════════════════════════════════════════════════════════════════

# R scripts
R_FUTSTK_SCRIPT = Path("/home/newuser_2/codex/extract_futstk_parquet_to_rds.R")
R_CASH_SCRIPT   = Path("/home/newuser_2/codex/extract_cash_parquet_to_rds.R")
RSCRIPT_BIN     = "Rscript"

# Parallel RDS workers
RDS_WORKERS_FUT  = 4   # FUTSTK
RDS_WORKERS_CM   = 4   # CM equities

# Local shared output root — RDS files go here at top level of DATE/
LOCAL_SHARED_ROOT = Path("/home/alpha/shared")

# ══════════════════════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════════════════════

def log(msg: str):
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def _fo_rds_out_paths(date: str, symbol: str, shared_date_dir: Path) -> tuple:
    """
    FO RDS naming (from extract_futstk_parquet_to_rds.R):
      TBT_SYMBOL_DATE.rds
      TBT_SYMBOL_DATE_aux.rds
    Placed at top level of shared/DATE/
    """
    main_rds = shared_date_dir / f"TBT_{symbol}_{date}.rds"
    aux_rds  = shared_date_dir / f"TBT_{symbol}_{date}_aux.rds"
    return main_rds, aux_rds


def _cm_rds_out_paths(date: str, symbol: str, shared_date_dir: Path) -> tuple:
    """
    CM RDS naming (from extract_cash_parquet_to_rds.R):
      TBT_SYMBOL_DATE.rds
      TBT_SYMBOL_DATE_aux.rds
    Placed at top level of shared/DATE/
    """
    main_rds = shared_date_dir / f"TBT_{symbol}_{date}.rds"
    aux_rds  = shared_date_dir / f"TBT_{symbol}_{date}_aux.rds"
    return main_rds, aux_rds


def _rds_already_done(main_rds: Path, aux_rds: Path) -> bool:
    return main_rds.exists() and aux_rds.exists()


# ══════════════════════════════════════════════════════════════════
# SINGLE FILE CONVERTER — FO (FUTSTK)
# ══════════════════════════════════════════════════════════════════

def _convert_one_fo(parquet_path: Path, date: str,
                    symbol: str, expiry: str,
                    shared_date_dir: Path,
                    overwrite: bool = False) -> dict:
    """
    Convert one FUTSTK parquet → RDS + aux RDS.
    Output: shared_date_dir/TBT_SYMBOL_DATE.rds
    Never raises — returns error dict on failure.
    """
    t0 = time.time()

    main_rds, aux_rds = _fo_rds_out_paths(date, symbol, shared_date_dir)

    if not overwrite and _rds_already_done(main_rds, aux_rds):
        log(f"[RDS-FO] exists — skipping {symbol}/{expiry}")
        return {
            "segment":   "FUTSTK",
            "symbol":    symbol,
            "expiry":    expiry,
            "status":    "exists",
            "elapsed_s": 0,
            "main_rds":  str(main_rds),
            "aux_rds":   str(aux_rds),
            "error":     "",
        }

    shared_date_dir.mkdir(parents=True, exist_ok=True)

    try:
        inline_r = f"""
source("{R_FUTSTK_SCRIPT}")
path         <- "{parquet_path}"
out_path     <- "{main_rds}"
aux_path     <- "{aux_rds}"
expiry_epoch <- "{expiry}"
symbol       <- "{symbol}"
trade_date   <- "{date}"
raw          <- read_parquet_data(path)
prepped      <- prep_tbt(raw)
prepped$expiry_epoch <- expiry_epoch
main_msg_types <- c("N","M","X","T")
aux_msg_types  <- c("G","H","J","K")
out  <- sort_tbt(prepped[prepped$msg_type %in% main_msg_types, , drop=FALSE])
aux  <- sort_tbt(prepped[prepped$msg_type %in% aux_msg_types,  , drop=FALSE])
dir.create(dirname(out_path), recursive=TRUE, showWarnings=FALSE)
saveRDS(out, out_path, compress="xz")
saveRDS(aux, aux_path, compress="xz")
cat(sprintf("main_rows=%d aux_rows=%d\\n", nrow(out), nrow(aux)))
"""
        result = subprocess.run(
            [RSCRIPT_BIN, "-e", inline_r],
            capture_output=True,
            text=True,
            timeout=3600,
        )

        elapsed = round(time.time() - t0)

        if result.returncode != 0:
            raise RuntimeError(
                f"Rscript exit {result.returncode}: "
                f"{result.stderr.strip()[-300:]}"
            )

        main_size = main_rds.stat().st_size if main_rds.exists() else 0
        aux_size  = aux_rds.stat().st_size  if aux_rds.exists()  else 0
        parq_size = parquet_path.stat().st_size if parquet_path.exists() else 0
        ratio     = round(parq_size / (main_size + aux_size), 2) if (main_size + aux_size) > 0 else 0

        log(f"[RDS-FO] done  FUTSTK/{symbol}/{expiry}  "
            f"({elapsed}s  ratio={ratio}x  "
            f"main={main_size/1e6:.1f}MB  aux={aux_size/1e6:.1f}MB)")

        return {
            "segment":           "FUTSTK",
            "symbol":            symbol,
            "expiry":            expiry,
            "status":            "done",
            "elapsed_s":         elapsed,
            "main_rds":          str(main_rds),
            "aux_rds":           str(aux_rds),
            "main_rds_mb":       round(main_size / 1e6, 2),
            "aux_rds_mb":        round(aux_size  / 1e6, 2),
            "parquet_mb":        round(parq_size / 1e6, 2),
            "compression_ratio": ratio,
            "error":             "",
        }

    except Exception as e:
        elapsed = round(time.time() - t0)
        log(f"[RDS-FO] WARN  FUTSTK/{symbol}/{expiry}  failed: {e}")
        return {
            "segment":   "FUTSTK",
            "symbol":    symbol,
            "expiry":    expiry,
            "status":    "error",
            "elapsed_s": elapsed,
            "main_rds":  "",
            "aux_rds":   "",
            "error":     str(e)[:300],
        }


# ══════════════════════════════════════════════════════════════════
# SINGLE FILE CONVERTER — CM (equities)
# ══════════════════════════════════════════════════════════════════

def _convert_one_cm(parquet_path: Path, date: str,
                    symbol: str, series: str,
                    shared_date_dir: Path,
                    overwrite: bool = False) -> dict:
    """
    Convert one CM parquet → RDS + aux RDS.
    Output: shared_date_dir/TBT_SYMBOL_DATE.rds
    Never raises — returns error dict on failure.
    """
    t0 = time.time()

    main_rds, aux_rds = _cm_rds_out_paths(date, symbol, shared_date_dir)

    if not overwrite and _rds_already_done(main_rds, aux_rds):
        log(f"[RDS-CM] exists — skipping {symbol}")
        return {
            "segment":   "CM",
            "symbol":    symbol,
            "expiry":    series,
            "status":    "exists",
            "elapsed_s": 0,
            "main_rds":  str(main_rds),
            "aux_rds":   str(aux_rds),
            "error":     "",
        }

    shared_date_dir.mkdir(parents=True, exist_ok=True)
    aux_dir = shared_date_dir / "aux"
    aux_dir.mkdir(parents=True, exist_ok=True)

    try:
        # Use inline R sourcing extract_cash_parquet_to_rds.R helpers
        inline_r = f"""
source("{R_FUTSTK_SCRIPT}")
path       <- "{parquet_path}"
out_path   <- "{main_rds}"
aux_path   <- "{aux_dir / f'TBT_{symbol}_{date}_aux.rds'}"
symbol     <- "{symbol}"
trade_date <- "{date}"
raw        <- read_parquet_data(path)
prepped    <- prep_tbt(raw)
main_msg_types <- c("N","M","X","T")
aux_msg_types  <- c("G","H","J","K")
out  <- sort_tbt(prepped[prepped$msg_type %in% main_msg_types, , drop=FALSE])
aux  <- sort_tbt(prepped[prepped$msg_type %in% aux_msg_types,  , drop=FALSE])
dir.create(dirname(out_path), recursive=TRUE, showWarnings=FALSE)
dir.create(dirname(aux_path), recursive=TRUE, showWarnings=FALSE)
saveRDS(out, out_path, compress="xz")
saveRDS(aux, aux_path, compress="xz")
cat(sprintf("main_rows=%d aux_rows=%d\\n", nrow(out), nrow(aux)))
"""
        result = subprocess.run(
            [RSCRIPT_BIN, "-e", inline_r],
            capture_output=True,
            text=True,
            timeout=3600,
        )

        elapsed = round(time.time() - t0)

        if result.returncode != 0:
            raise RuntimeError(
                f"Rscript exit {result.returncode}: "
                f"{result.stderr.strip()[-300:]}"
            )

        # aux RDS path — same as FO pattern but in aux/ subdir
        actual_aux = aux_dir / f"TBT_{symbol}_{date}_aux.rds"

        main_size = main_rds.stat().st_size if main_rds.exists() else 0
        aux_size  = actual_aux.stat().st_size if actual_aux.exists() else 0
        parq_size = parquet_path.stat().st_size if parquet_path.exists() else 0
        ratio     = round(parq_size / (main_size + aux_size), 2) if (main_size + aux_size) > 0 else 0

        log(f"[RDS-CM] done  CM/{symbol}  "
            f"({elapsed}s  ratio={ratio}x  "
            f"main={main_size/1e6:.1f}MB  aux={aux_size/1e6:.1f}MB)")

        return {
            "segment":           "CM",
            "symbol":            symbol,
            "expiry":            series,
            "status":            "done",
            "elapsed_s":         elapsed,
            "main_rds":          str(main_rds),
            "aux_rds":           str(actual_aux),
            "main_rds_mb":       round(main_size / 1e6, 2),
            "aux_rds_mb":        round(aux_size  / 1e6, 2),
            "parquet_mb":        round(parq_size / 1e6, 2),
            "compression_ratio": ratio,
            "error":             "",
        }

    except Exception as e:
        elapsed = round(time.time() - t0)
        log(f"[RDS-CM] WARN  CM/{symbol}  failed: {e}")
        return {
            "segment":   "CM",
            "symbol":    symbol,
            "expiry":    series,
            "status":    "error",
            "elapsed_s": elapsed,
            "main_rds":  "",
            "aux_rds":   "",
            "error":     str(e)[:300],
        }


# ══════════════════════════════════════════════════════════════════
# RDS JOB MANAGER — FO (FUTSTK)
# ══════════════════════════════════════════════════════════════════

class RdsJobManager:
    """
    Manages parallel FUTSTK RDS jobs.
    Submits as each parquet is atomically written (overlapping with merge).
    Retry failed once before TAR stage.

    Usage:
      mgr = RdsJobManager(date="20260320", shared_date_dir=Path("/home/alpha/shared/20260320"))
      mgr.submit(parquet_path, symbol, expiry)   # called from merge thread
      results = mgr.wait_and_retry()             # barrier before TAR
      mgr.write_summary(summary_path, results)
    """

    def __init__(self, date: str, shared_date_dir: Path, overwrite: bool = False):
        self.date             = date
        self.shared_date_dir  = shared_date_dir
        self.overwrite        = overwrite

        self._pool      = ThreadPoolExecutor(max_workers=RDS_WORKERS_FUT,
                                              thread_name_prefix="rds_fut")
        self._futures: list[tuple[Future, dict]] = []
        self._lock      = threading.Lock()
        self._skipped   = 0
        self._submitted = 0

    def submit(self, parquet_path: Path, symbol: str, expiry: str):
        """
        Submit one FUTSTK parquet for RDS conversion.
        Safe to call from any thread.
        Call immediately after atomic rename of parquet.
        segment is always FUTSTK.
        """
        job_meta = {
            "parquet_path": parquet_path,
            "symbol":       symbol,
            "expiry":       expiry,
        }

        future = self._pool.submit(
            _convert_one_fo,
            parquet_path, self.date, symbol, expiry,
            self.shared_date_dir, self.overwrite,
        )

        with self._lock:
            self._futures.append((future, job_meta))
            self._submitted += 1

        log(f"[RDS-FO] submitted FUTSTK/{symbol}/{expiry}")

    def wait_and_retry(self) -> dict:
        """
        BARRIER — wait for all submitted FO RDS jobs.
        Retry failed ones once.
        Returns summary dict.
        """
        if not self._futures:
            log(f"[RDS-FO] No jobs submitted (skipped={self._skipped})")
            return {"done": [], "failed": [], "exists": [], "retried_ok": [], "retried_fail": []}

        log(f"[RDS-FO] Waiting for {self._submitted} FUTSTK jobs ...")

        done_results   = []
        failed_jobs    = []
        exists_results = []

        for future, job_meta in self._futures:
            try:
                result = future.result()
            except Exception as e:
                result = {
                    **{k: str(v) for k, v in job_meta.items()},
                    "segment":   "FUTSTK",
                    "status":    "error",
                    "error":     str(e)[:300],
                    "elapsed_s": 0,
                }

            if result["status"] == "done":
                done_results.append(result)
            elif result["status"] == "exists":
                exists_results.append(result)
            else:
                failed_jobs.append((result, job_meta))
                log(f"[RDS-FO] WARN first attempt failed: "
                    f"FUTSTK/{result['symbol']}/{result['expiry']}"
                    f" — {result.get('error','')[:100]}")

        log(f"[RDS-FO] First attempt: "
            f"{len(done_results)} done  "
            f"{len(exists_results)} exists  "
            f"{len(failed_jobs)} failed")

        # ── Retry failed once ──────────────────────────────────────
        retried_ok   = []
        retried_fail = []

        if failed_jobs:
            log(f"[RDS-FO] Retrying {len(failed_jobs)} failed jobs ...")
            for _first, job_meta in failed_jobs:
                retry = _convert_one_fo(
                    job_meta["parquet_path"],
                    self.date,
                    job_meta["symbol"],
                    job_meta["expiry"],
                    self.shared_date_dir,
                    self.overwrite,
                )
                if retry["status"] == "done":
                    retried_ok.append(retry)
                    log(f"[RDS-FO] retry OK  FUTSTK/{retry['symbol']}/{retry['expiry']}")
                else:
                    retried_fail.append(retry)
                    log(f"[RDS-FO] WARN retry FAILED  "
                        f"FUTSTK/{retry['symbol']}/{retry['expiry']}  "
                        f"— {retry.get('error','')[:100]}")

        self._pool.shutdown(wait=False)

        total_done   = len(done_results) + len(retried_ok)
        total_failed = len(retried_fail)
        total_exists = len(exists_results)
        log(f"[RDS-FO] Complete — done={total_done}  exists={total_exists}  failed={total_failed}")

        if retried_fail:
            log(f"[RDS-FO] WARNING — {total_failed} symbols failed after retry:")
            for r in retried_fail:
                log(f"  ✗ FUTSTK/{r['symbol']}/{r['expiry']}")

        return {
            "done":         done_results,
            "exists":       exists_results,
            "failed":       [],
            "retried_ok":   retried_ok,
            "retried_fail": retried_fail,
        }

    def write_summary(self, summary_path: Path, results: dict):
        _write_rds_summary(summary_path, results)


# ══════════════════════════════════════════════════════════════════
# CM RDS RUNNER — runs after CM merge completes
# ══════════════════════════════════════════════════════════════════

def run_cm_rds(cm_final_dir: Path, date: str,
               shared_date_dir: Path,
               overwrite: bool = False,
               summary_path: Path = None) -> dict:
    """
    Convert all CM parquets in cm_final_dir to RDS.
    cm_final_dir: local work dir CM_Data/ with DATE_SYMBOL_EQ.parquet files
    RDS output  : shared_date_dir/TBT_SYMBOL_DATE.rds (top level)

    Runs in parallel with RDS_WORKERS_CM workers.
    Retries failures once.
    """
    shared_date_dir.mkdir(parents=True, exist_ok=True)

    # Find all CM parquets: DATE_SYMBOL_SERIES.parquet
    pattern = f"{date}_*.parquet"
    parquets = sorted(cm_final_dir.glob(pattern))

    if not parquets:
        log(f"[RDS-CM] No CM parquets found in {cm_final_dir}")
        return {"done": [], "exists": [], "retried_ok": [], "retried_fail": []}

    log(f"[RDS-CM] Found {len(parquets)} CM parquets — starting RDS conversion ...")

    # Parse symbol + series from filename: DATE_SYMBOL_SERIES.parquet
    jobs = []
    for pq in parquets:
        stem  = pq.stem  # e.g. 20260525_BANDHANBNK_EQ
        parts = stem.split("_")
        if len(parts) < 3:
            log(f"[RDS-CM] WARN cannot parse filename: {pq.name} — skipping")
            continue
        # parts[0]=date, parts[-1]=series, parts[1:-1]=symbol (handles multi-part symbols)
        series = parts[-1]
        symbol = "_".join(parts[1:-1])
        jobs.append((pq, symbol, series))

    if not jobs:
        log(f"[RDS-CM] No valid CM parquets to convert")
        return {"done": [], "exists": [], "retried_ok": [], "retried_fail": []}

    # Parallel conversion
    done_results   = []
    failed_jobs    = []
    exists_results = []

    with ThreadPoolExecutor(max_workers=RDS_WORKERS_CM, thread_name_prefix="rds_cm") as pool:
        future_map = {
            pool.submit(
                _convert_one_cm,
                pq, date, symbol, series, shared_date_dir, overwrite
            ): (pq, symbol, series)
            for pq, symbol, series in jobs
        }
        for future in as_completed(future_map):
            pq, symbol, series = future_map[future]
            try:
                result = future.result()
            except Exception as e:
                result = {
                    "segment":   "CM",
                    "symbol":    symbol,
                    "expiry":    series,
                    "status":    "error",
                    "elapsed_s": 0,
                    "main_rds":  "",
                    "aux_rds":   "",
                    "error":     str(e)[:300],
                }

            if result["status"] == "done":
                done_results.append(result)
            elif result["status"] == "exists":
                exists_results.append(result)
            else:
                failed_jobs.append((result, pq, symbol, series))
                log(f"[RDS-CM] WARN first attempt failed: CM/{symbol} — {result.get('error','')[:100]}")

    log(f"[RDS-CM] First attempt: "
        f"{len(done_results)} done  "
        f"{len(exists_results)} exists  "
        f"{len(failed_jobs)} failed")

    # ── Retry failed once ──────────────────────────────────────────
    retried_ok   = []
    retried_fail = []

    if failed_jobs:
        log(f"[RDS-CM] Retrying {len(failed_jobs)} failed jobs ...")
        for _first, pq, symbol, series in failed_jobs:
            retry = _convert_one_cm(pq, date, symbol, series, shared_date_dir, overwrite)
            if retry["status"] == "done":
                retried_ok.append(retry)
                log(f"[RDS-CM] retry OK  CM/{symbol}")
            else:
                retried_fail.append(retry)
                log(f"[RDS-CM] WARN retry FAILED  CM/{symbol}  — {retry.get('error','')[:100]}")

    total_done   = len(done_results) + len(retried_ok)
    total_failed = len(retried_fail)
    total_exists = len(exists_results)
    log(f"[RDS-CM] Complete — done={total_done}  exists={total_exists}  failed={total_failed}")

    if retried_fail:
        log(f"[RDS-CM] WARNING — {total_failed} CM symbols failed after retry:")
        for r in retried_fail:
            log(f"  ✗ CM/{r['symbol']}")

    results = {
        "done":         done_results,
        "exists":       exists_results,
        "failed":       [],
        "retried_ok":   retried_ok,
        "retried_fail": retried_fail,
    }

    if summary_path:
        _write_rds_summary(summary_path, results)

    return results


# ══════════════════════════════════════════════════════════════════
# SHARED SUMMARY WRITER
# ══════════════════════════════════════════════════════════════════

def _write_rds_summary(summary_path: Path, results: dict):
    all_results = (
        results.get("done", []) +
        results.get("exists", []) +
        results.get("retried_ok", []) +
        results.get("retried_fail", [])
    )
    if not all_results:
        return

    fieldnames = [
        "segment", "symbol", "expiry", "status",
        "parquet_mb", "main_rds_mb", "aux_rds_mb",
        "compression_ratio", "elapsed_s", "error",
        "parquet", "main_rds", "aux_rds",
    ]
    try:
        with open(summary_path, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
            w.writeheader()
            for r in sorted(all_results,
                             key=lambda x: (x.get("segment", ""),
                                            x.get("symbol", ""),
                                            x.get("expiry", ""))):
                w.writerow(r)
        log(f"[RDS] Summary written → {summary_path}")
    except Exception as e:
        log(f"[RDS] WARN — could not write summary: {e}")
